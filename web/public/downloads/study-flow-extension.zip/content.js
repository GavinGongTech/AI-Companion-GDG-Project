(function(){let e=`data-study-flow-content`;if(document.documentElement.getAttribute(e))return;document.documentElement.setAttribute(e,`1`);let t=window.location.hostname.toLowerCase(),n=null;if(t.includes(`brightspace`)?n=`brightspace`:t.includes(`gradescope.com`)&&(n=`gradescope`),!n)return;function r(){let e=n===`brightspace`?[`.d2l-page-main`,`.d2l-content-container`,`#ContentView`]:[`.submissionContent`,`.rubricContent`,`.questionContent`];for(let t of e){let e=document.querySelector(t);if(e&&e.innerText.trim().length>0)return e.innerText.trim()}return(document.body.innerText||``).trim()}let i=r();if(!i)return;let a=i.slice(0,100)+`|`+i.length,o=`studyflow_last_hash`,s=localStorage.getItem(o)===a;localStorage.setItem(o,a);let c=!1;s||(chrome.runtime.sendMessage({type:`INGEST_PAGE`,payload:{rawContent:i,courseName:document.title,sourcePlatform:n}}),c=!0);let l=document.createElement(`div`);l.id=`studyflow-fab-host`,document.body.appendChild(l);let u=l.attachShadow({mode:`closed`}),d=document.createElement(`style`);d.textContent=`
    * { box-sizing: border-box; margin: 0; padding: 0; }
    .fab {
      position: fixed;
      bottom: 20px;
      right: 20px;
      z-index: 999999;
      width: 48px;
      height: 48px;
      border-radius: 50%;
      background: #3ee0d0;
      border: none;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 2px 8px rgba(0,0,0,0.3);
      font-size: 20px;
      color: #101620;
      transition: transform 0.15s ease;
    }
    .fab:hover { transform: scale(1.08); }
    .fab .badge {
      position: absolute;
      top: -4px;
      right: -4px;
      font-size: 9px;
      font-weight: 700;
      background: #101620;
      color: #3ee0d0;
      padding: 2px 5px;
      border-radius: 8px;
      pointer-events: none;
    }
    .panel {
      position: fixed;
      bottom: 76px;
      right: 20px;
      z-index: 999999;
      background: #101620;
      border: 1px solid rgba(255,255,255,0.08);
      border-radius: 12px;
      padding: 12px;
      display: none;
      flex-direction: column;
      gap: 8px;
      box-shadow: 0 4px 16px rgba(0,0,0,0.4);
      min-width: 150px;
    }
    .panel.open { display: flex; }
    .panel button {
      background: rgba(62,224,208,0.12);
      color: #3ee0d0;
      border: 1px solid rgba(62,224,208,0.25);
      border-radius: 8px;
      padding: 8px 14px;
      cursor: pointer;
      font-size: 13px;
      font-weight: 600;
      transition: background 0.15s ease;
    }
    .panel button:hover {
      background: rgba(62,224,208,0.22);
    }
  `,u.appendChild(d);let f=document.createElement(`button`);f.className=`fab`,f.innerHTML=`&#9733;`,f.title=`Study Flow`,u.appendChild(f);let p=document.createElement(`span`);p.className=`badge`,p.textContent=`Ingested`,p.style.display=c?`block`:`none`,f.appendChild(p);let m=document.createElement(`div`);m.className=`panel`,u.appendChild(m);let h=document.createElement(`button`);h.textContent=`Explain this`,m.appendChild(h);let g=document.createElement(`button`);g.textContent=`Quiz me`,m.appendChild(g),f.addEventListener(`click`,function(){m.classList.toggle(`open`)}),h.addEventListener(`click`,function(){let e=window.getSelection().toString();chrome.runtime.sendMessage({type:`OPEN_ASK`,payload:{selectedText:e||i.slice(0,500)}}),m.classList.remove(`open`)}),g.addEventListener(`click`,function(){chrome.runtime.sendMessage({type:`OPEN_QUIZ`}),m.classList.remove(`open`)}),console.info(`[Study Flow] Content script loaded on`,n,window.location.href)})();