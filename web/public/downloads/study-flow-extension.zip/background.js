//#region src/background.js
var WEB_URL = "http://localhost:5173";
var allowedWebOrigins = new Set(["http://localhost:5173", "http://127.0.0.1:5173"]);
try {
	allowedWebOrigins.add(new URL(WEB_URL).origin);
} catch {}
chrome.runtime.onInstalled.addListener(() => {
	chrome.sidePanel.setOptions({
		path: "sidepanel.html",
		enabled: true
	});
});
chrome.action.onClicked.addListener((tab) => {
	if (tab.windowId !== void 0) chrome.sidePanel.open({ windowId: tab.windowId });
});
function isSafeWebUrl(url) {
	try {
		const parsed = new URL(url);
		return allowedWebOrigins.has(parsed.origin);
	} catch {
		return false;
	}
}
function isSafeApiUrl(url) {
	try {
		const parsed = new URL(url);
		if (parsed.protocol === "https:") return true;
		if (parsed.protocol === "http:" && (parsed.hostname === "localhost" || parsed.hostname === "127.0.0.1")) return true;
		return false;
	} catch {
		return false;
	}
}
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
	if (message.type === "INGEST_PAGE") {
		chrome.storage.session.set({ lastIngestedContent: message.payload });
		ingestToBackend(message.payload).then(() => sendResponse({ ok: true })).catch((err) => sendResponse({
			ok: false,
			error: err.message
		}));
		return true;
	}
	if (message.type === "OPEN_ASK") {
		chrome.storage.session.set({ prefillAsk: message.payload?.selectedText || "" });
		if (sender.tab?.windowId !== void 0) chrome.sidePanel.open({ windowId: sender.tab.windowId });
		sendResponse({ ok: true });
		return false;
	}
	if (message.type === "OPEN_QUIZ") {
		if (sender.tab?.windowId !== void 0) chrome.sidePanel.open({ windowId: sender.tab.windowId });
		chrome.storage.session.set({ navigateTo: "quiz" });
		sendResponse({ ok: true });
		return false;
	}
	return false;
});
chrome.runtime.onMessageExternal.addListener((message, sender, sendResponse) => {
	if (message?.type !== "AUTH_FROM_WEB") return false;
	if (!sender.url || !isSafeWebUrl(sender.url)) {
		sendResponse({
			ok: false,
			error: "Unauthorized sender."
		});
		return false;
	}
	if (!message.token || !message.user) {
		sendResponse({
			ok: false,
			error: "Missing auth payload."
		});
		return false;
	}
	chrome.storage.session.set({
		firebaseIdToken: message.token,
		authUser: message.user
	}).then(() => sendResponse({ ok: true })).catch((err) => sendResponse({
		ok: false,
		error: err.message
	}));
	return true;
});
async function ingestToBackend(payload) {
	const apiUrl = ((await chrome.storage.local.get(["apiUrl"])).apiUrl || "http://localhost:3000").replace(/\/+$/, "");
	if (!isSafeApiUrl(apiUrl)) throw new Error("Unsafe API URL configuration. Use HTTPS (or localhost for local development).");
	const token = (await chrome.storage.session.get(["firebaseIdToken"])).firebaseIdToken;
	if (!token) return;
	const res = await fetch(`${apiUrl}/api/v1/ingest/text`, {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			Authorization: `Bearer ${token}`
		},
		body: JSON.stringify({
			courseId: payload.courseName || "general",
			rawContent: payload.rawContent,
			sourcePlatform: payload.sourcePlatform
		})
	});
	if (!res.ok) {
		const body = await res.json().catch(() => ({}));
		throw new Error(body.error || res.statusText);
	}
}
//#endregion

//# sourceMappingURL=background.js.map